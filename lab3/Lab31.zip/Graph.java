import java.util.ArrayList;

public class Graph {
    private ArrayList<Vertex> vertices;

    public Graph() {
        vertices = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            addVertex();
        }
        addEdge(0, 1);
        addEdge(0, 2);
        addEdge(0, 3);
        addEdge(2, 4);
    }

    public void addVertex() {
        int vertexNumber = vertices.size();
        Vertex newVertex = new Vertex(vertexNumber);
        vertices.add(newVertex);
    }

    public Vertex getVertex(int vertexNumber) {
        if (vertexNumber >= 0 && vertexNumber < vertices.size()) {
            return vertices.get(vertexNumber);
        }
        return null;
    }

    public void addEdge(int v1, int v2) {
        Vertex vertex1 = getVertex(v1);
        Vertex vertex2 = getVertex(v2);
        if (vertex1 != null && vertex2 != null && v1 != v2) {
            vertex1.addAdjacency(vertex2);
            vertex2.addAdjacency(vertex1);
        }
    }
}

