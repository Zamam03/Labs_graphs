import java.util.LinkedList;

public class Vertex {
    private int vertexNumber;
    private int colour;
    private LinkedList<Vertex> adjacencies;

    public Vertex(int vertexNumber) {
        this.vertexNumber = vertexNumber;
        this.colour = 0;
        this.adjacencies = new LinkedList<>();
    }

    public void addAdjacency(Vertex v) {
        if (!adjacencies.contains(v)) {
            adjacencies.add(v);
        }
    }

    public boolean isAdjacent(Vertex v) {
        return adjacencies.contains(v);
    }

    public int getDegree() {
        return adjacencies.size();
    }

    public int getVertexNumber() {
        return vertexNumber;
    }

    public void setColour(int colour) {
        this.colour = colour;
    }
    
    public int getColour() {
        return colour;
    }
}

