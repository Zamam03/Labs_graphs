import java.util.LinkedList;

public class Vertex {
    private int vertexNumber;
    private int color;
    private LinkedList<Vertex> adjacencies;

    public Vertex(int vertexNumber) {
        this.vertexNumber = vertexNumber;
        this.adjacencies = new LinkedList<>();
    }

    public void addAdjacency(Vertex vertex) {
        adjacencies.add(vertex);
    }

    public boolean isAdjacent(Vertex vertex) {
        return adjacencies.contains(vertex);
    }

    public int getDegree() {
        return adjacencies.size();
    }

    // Getters and setters for vertexNumber and color
    public int getVertexNumber() {
        return vertexNumber;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getColor() {
        return color;
    }
}

