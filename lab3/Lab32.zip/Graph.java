import java.util.ArrayList;

public class Graph {
    private ArrayList<Vertex> vertices;

    public Graph() {
        vertices = new ArrayList<>();
        
        addVertex();
        addVertex();
        addVertex();
        addVertex();
        addVertex();

        addEdge(0, 1);
        addEdge(0, 2);
        addEdge(0, 3);
        addEdge(2, 4);
    }

    public void addVertex() {
        vertices.add(new Vertex(vertices.size()));
    }

    public Vertex getVertex(int vertexNumber) {
        return vertices.get(vertexNumber);
    }

    public void addEdge(int vertex1, int vertex2) {
        Vertex v1 = vertices.get(vertex1);
        Vertex v2 = vertices.get(vertex2);
        v1.addAdjacency(v2);
        v2.addAdjacency(v1);
    }
}

